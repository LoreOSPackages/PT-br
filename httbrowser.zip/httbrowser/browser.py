import requests
import textwrap

def fetch_url(url):
    try:
        response = requests.get(url)
        response.raise_for_status()
        return response.text
    except Exception as e:
        return f"[Erro] Falha ao carregar {url}: {e}"


def display_text(text, width=80):
    for line in text.splitlines():
        wrapped = textwrap.fill(line, width=width)
        print(wrapped)
