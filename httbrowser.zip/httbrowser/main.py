from browser import fetch_url, display_text

def main():
    print("=== Navegador de Console ===")
    while True:
        url = input("URL (ou 'sair'): ").strip()
        if url.lower() in ["sair", "exit", "quit"]:
            break
        html = fetch_url(url)
        display_text(html)

if __name__ == "__main__":
    main()
